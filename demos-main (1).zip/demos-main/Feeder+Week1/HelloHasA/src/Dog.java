
public class Dog {

	public static int legs = 4;
	
	public void bark() {
		System.out.println("bork bork bork");
	}
	
}
