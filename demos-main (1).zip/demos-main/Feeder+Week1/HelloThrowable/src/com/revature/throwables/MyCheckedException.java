package com.revature.throwables;

public class MyCheckedException extends Exception {

	//this is a checked exception... we're not gonna do anything here
	//Just know that by extending the Generic Exception class, that makes it a Checked Exception

}
